'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"assets/AssetManifest.bin": "fa89dd05d5648378e3e8e62295f1c65f",
"assets/AssetManifest.bin.json": "38fe059485b55893774994d88481c3fc",
"assets/AssetManifest.json": "fb5d6c55f987c5c45b956782f2a97ce1",
"assets/assets/fonts/HelveticaNeue-Bold.ttf": "7f281199258d96e249a7fce4101006b9",
"assets/assets/fonts/HelveticaNeue-Light.ttf": "0facaae97183b8fede52099930aefd8d",
"assets/assets/fonts/HelveticaNeue-Medium.ttf": "0a13c540938b1b7dd3996b02ea568e5f",
"assets/assets/fonts/HelveticaNeue-Regular.ttf": "6f0cc998e7a41af98660bec40b7d20b4",
"assets/assets/images/account_balance_wallet.png": "e4adc6ada1a7331bb237a08c268c1bc1",
"assets/assets/images/account_circle.png": "cc38c9e21b4356b9f5768299f6a7de73",
"assets/assets/images/arrowDown.png": "a6fc112e96c19db0fb2b1ce47022f15d",
"assets/assets/images/arrowUp.png": "de91f0e9a42718794c5713ebec0a350c",
"assets/assets/images/arrow_back_ios_new.png": "a6fc112e96c19db0fb2b1ce47022f15d",
"assets/assets/images/article.png": "544488df892676dbead5334d3c58f74c",
"assets/assets/images/assignment.png": "ff312ac8e67e00c9c61f0e2ca494c318",
"assets/assets/images/badge.png": "833a907b7b8d07505d9bd6482aa1c2f7",
"assets/assets/images/badge_.png": "3a78eac37878e3afe687729d20477fe9",
"assets/assets/images/bancoCaribeLogo.png": "38675de85926e4b70454e95252383208",
"assets/assets/images/BancoCaribeTextLogo.png": "eaf2cdae1a6227773980cb616e05e9da",
"assets/assets/images/bancoWhiteLogo.png": "5041bfbd5bf84833b3237ed1badea4d8",
"assets/assets/images/bigLogo.png": "03c19cb7d72f8c016daa94049391f099",
"assets/assets/images/bullet.png": "98658eb9a85f5490867f4cb9d527bf1a",
"assets/assets/images/calendar.png": "3b5e687839ba24634b916e3e51d16c72",
"assets/assets/images/camera.png": "90da4f596266f1f5e133e8efc411bd9b",
"assets/assets/images/caribeDigital.png": "322d0c27c354d3289df5396721cc8bef",
"assets/assets/images/checkIcon.png": "8994f4b76e42157d755399a1327f1dd9",
"assets/assets/images/close.png": "4313c9c476ffa2c6de0ef671e0f925d1",
"assets/assets/images/Contact_us_bank_logo.png": "2fb478b2b979b4b130ce811b64c1e476",
"assets/assets/images/Contact_us_Logo.png": "a86b1a568a3bbc3d6186e008441575f0",
"assets/assets/images/contract_edit.png": "a83d749f39a61346ef112332f1bbeea4",
"assets/assets/images/dollorIcon.png": "66107f4c73b088e762ebe171e47c9ef6",
"assets/assets/images/emailliconotp.png": "55ba73e3b438cb388c588d68b270d908",
"assets/assets/images/facebook.png": "d7bdc9420617e7c80055e0aa0431aec8",
"assets/assets/images/face_verification_tick.png": "cea7b76e7050a4a6e26e4fc2205ec767",
"assets/assets/images/header.png": "175c01d35a3f30c3253742d081cbb849",
"assets/assets/images/horizontaldash.png": "c14bb5ab43dfc067d0dcee758abfd9ea",
"assets/assets/images/info.png": "4e42d2d1f47aec1b510c74cd2aa952d5",
"assets/assets/images/initialLogo.png": "319cbaad01e7e73bc5ec745f58e94de6",
"assets/assets/images/initialLogo1.png": "bddc3a0c697009a6d73327ca7e07a2df",
"assets/assets/images/initialLogoDesktop.png": "64da52af8af4e142b4b79dbda62903c5",
"assets/assets/images/initialLogoDesktop1.png": "a3d5403f45f6e1c16aec61134eaf0706",
"assets/assets/images/instagram.png": "21ec130a36e3993d20b6b737d60159ab",
"assets/assets/images/mobileImage.png": "319cbaad01e7e73bc5ec745f58e94de6",
"assets/assets/images/p6.png": "0a99d644bf159fc7f23b189b4d3a9827",
"assets/assets/images/photo_legible.png": "d2c87b3bc684ba91a47dd828639ac3c6",
"assets/assets/images/photo_legible_tick.png": "b95e85d09c6d3e01759490dc9a18e9e1",
"assets/assets/images/Rectangle%25204.png": "8d1c75305bc95d2b58d7ea404f14286d",
"assets/assets/images/resources.png": "8777a376191762f0f7941bc499d25a96",
"assets/assets/images/screenshot.png": "ef23c3caa5895661a288b94c5e70d939",
"assets/assets/images/smallLogo.png": "e604db463ac08e142eb4ef9611aa29ef",
"assets/assets/images/splashBancoCaribe.png": "227c3a7a7af294269d6106416c1283ab",
"assets/assets/images/stepper1.png": "02f7af9234449f02dba54dbdbd4db20e",
"assets/assets/images/stepper2.png": "c5a604dd6e9e7b1d0b54c39278848bb4",
"assets/assets/images/stepper3.png": "6178c8e69c8ffad1594132517c4a05ed",
"assets/assets/images/stepper4.png": "df59d3c693a5d2c3765e8cf57d2b490c",
"assets/assets/images/stepper5.png": "958d6888d5c5ef047ecda0ba468dabe7",
"assets/assets/images/stepperlogo.png": "d8e2e76faa5ee9512cfa0ffcc3b2a143",
"assets/assets/images/titleLogo.png": "47df61b17c10861c1946050475b1469e",
"assets/assets/images/upload.png": "0a86bb50dac6b32c4434304af161d3bf",
"assets/assets/images/upload_cedula.png": "eaaae06d2b99e075705ea87a07ade487",
"assets/assets/images/upload_cedula_back.png": "98beefc56ca020e899f45b5560d3c408",
"assets/assets/images/verticledash.png": "d2a87267a23e34b84c2963ef4e9b89ae",
"assets/assets/images/webimage.png": "64da52af8af4e142b4b79dbda62903c5",
"assets/assets/images/welcomeImage.png": "301fe4304732488ea622191b6dd3def4",
"assets/assets/images/x.png": "7a4aac6a0762e160ea8aaac188462465",
"assets/assets/images/youtube.png": "e1d866a4acc21d6d7f4351029ff92de2",
"assets/assets/pdf/Carta_de_Debris.pdf": "a758716ba4d3c34d07b520b186f979a0",
"assets/assets/pdf/CONTRATO_DE%2520_APERTURA_DE_CUENTA_DIGITAL_CARIBE.pdf": "6baf765acde9657008368cc18438e1d5",
"assets/assets/pdf/CONTRATO_DE%2520_APERTURA_DE_CUENTA_DIGITAL_CARIBE_SHOW.pdf": "dab9d3bb85ac2864878172026c6e6e42",
"assets/assets/pdf/CONVENIO_UNICO_FINAL_2018_9_10.pdf": "6593d16b719664fab95f392960a3c510",
"assets/assets/pdf/Convincio_Inicio.pdf": "2e60ae1a032dc4a9e37dc86475b145a0",
"assets/assets/pdf/one_shot_contract.pdf": "c7a34526765ab893bfa4e104da24d8a7",
"assets/assets/pdf/Tarifario.pdf": "5337432f0bb459baa9c24f221a72ae60",
"assets/assets/pdf/TarifarioRd.pdf": "038289e2214b3594fd553102ed9b2e7b",
"assets/assets/pdf/TERMINOS_Y_CONDICIONES%2520_ONBOARDING.pdf": "96057e737f3f7825e7000ee19f09a8af",
"assets/FontManifest.json": "b5ff9b04f3f4c8229afa3a67a1ba89a3",
"assets/fonts/MaterialIcons-Regular.otf": "47c4771cd67930435d4e3abfea2c5ab9",
"assets/NOTICES": "5e854d536b302f8adcdd80f9091e708a",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "e986ebe42ef785b27164c36a9abc7818",
"assets/packages/fluttertoast/assets/toastify.css": "a85675050054f179444bc5ad70ffc635",
"assets/packages/fluttertoast/assets/toastify.js": "56e2c9cedd97f10e7e5f1cebd85d53e3",
"assets/shaders/ink_sparkle.frag": "4096b5150bac93c41cbc9b45276bd90f",
"canvaskit/canvaskit.js": "eb8797020acdbdf96a12fb0405582c1b",
"canvaskit/canvaskit.wasm": "73584c1a3367e3eaf757647a8f5c5989",
"canvaskit/chromium/canvaskit.js": "0ae8bbcc58155679458a0f7a00f66873",
"canvaskit/chromium/canvaskit.wasm": "143af6ff368f9cd21c863bfa4274c406",
"canvaskit/skwasm.js": "87063acf45c5e1ab9565dcf06b0c18b8",
"canvaskit/skwasm.wasm": "2fc47c0a0c3c7af8542b601634fe9674",
"canvaskit/skwasm.worker.js": "bfb704a6c714a75da9ef320991e88b03",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "59a12ab9d00ae8f8096fffc417b6e84f",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "9521d4e99e7a6dec63f086d1972c6cae",
"/": "9521d4e99e7a6dec63f086d1972c6cae",
"main.dart.js": "602b963f4035d724cb0e463ad82afbbb",
"manifest.json": "cf240ec885d737059f87e1f39e02c369",
"version.json": "9e7a365cceb0c7be133a138a855e08d4"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
